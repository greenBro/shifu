package yuangong.id.ui.activity;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import yuangong.id.AppConstant;
import yuangong.id.R;
import yuangong.id.bean.ImageBean;
import yuangong.id.net.NetWorkUtils;
import yuangong.id.ui.activity.base.BaseActivity;
import yuangong.id.utils.AppUtils;
import yuangong.id.utils.BitmapFactoryUtils;
import yuangong.id.utils.DBManager;
import yuangong.id.utils.JSONUtils;
import yuangong.id.utils.JudgeNetWork;
import yuangong.id.utils.SharePreferenceUtils;

public class NotAccomplishDetailActivity extends BaseActivity {


    @Bind(R.id.title_back)
    ImageView mTitleBack;
    @Bind(R.id.title_text)
    TextView mTitleText;
    @Bind(R.id.user_name)
    TextView mUserName;
    @Bind(R.id.car_number)
    TextView mCarNumber;
    @Bind(R.id.stop_site)
    TextView mStopSite;
    @Bind(R.id.product_type)
    TextView mProductType;
    @Bind(R.id.order_time)
    TextView mOrderTime;
    @Bind(R.id.clear_status)
    TextView mClearStatus;
    @Bind(R.id.user_remark)
    TextView mUserRemark;
    @Bind(R.id.clear_forward1)
    ImageView mClearForward1;
    @Bind(R.id.clear_forward2)
    ImageView mClearForward2;
    @Bind(R.id.clear_back1)
    ImageView mClearBack1;
    @Bind(R.id.clear_back2)
    ImageView mClearBack2;
    @Bind(R.id.staff_remark)
    EditText mStaffRemark;
    @Bind(R.id.delay_oneday)
    TextView mDelayOneday;
    @Bind(R.id.sure_clear)
    TextView mSureClear;
    @Bind(R.id.vMasker)
    View mVMasker;
    @Bind(R.id.delete_forward1)
    ImageView mDeletaForward1;
    @Bind(R.id.delete_forward2)
    ImageView mDeletaForward2;
    @Bind(R.id.delete_back1)
    ImageView mDeletaAfter1;
    @Bind(R.id.delete_back2)
    ImageView mDeleteAfter2;
    public static final int REQUEST_CODE_CAMERA1 = 701;
    public static final int REQUEST_CODE_CAMERA2 = 702;
    public static final int REQUEST_CODE_CAMERA3 = 703;
    public static final int REQUEST_CODE_CAMERA4 = 704;
    private static final String dirName = Environment.getExternalStorageDirectory() + "/" + AppConstant.STAFF_FILENAME;
    private int mOrder_id;
    private String mFileBeforeName1; //洗车前照片名称1
    private String mFileBeforeName2;//洗车前照片名称2
    private String mFileAfterName1;//洗车后照片名称1
    private String mFileAfterName2;//洗车后照片名称2
    private String imgBefore1Path = "";  //图片在服务器的地址
    private String imgBefore2Path = "";
    private String imgAfter1Path = "";
    private String imgAfter2Path = "";
    private String imgBefore1Id = "";
    private String imgBefore2Id = "";
    private String imgAfter1Id = "";
    private String imgAfter2Id = "";
    private String mReserve_info_id;
    private AlertDialog mAlertDialog;
    private String mDeyReason;
    private AlertDialog mAlertDialog1;
    public static String TABLE_NAME = "clear_photo_cache";
    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            int what = msg.what;
            if (what == 1){
                AppUtils.setToastMsg(context,"缓存成功");
            }else if (what == 2){
                AppUtils.setToastMsg(context,"缓存失败");
            }else if (what == 3){
                AppUtils.setToastMsg(context,"缓存成功");
            }
        }
    };
    private String mStaffId;
    private long mReserve_time;
    private DBManager mDbManager;

    @Override
    protected void initData() {

        mTitleBack.setVisibility(View.VISIBLE);
        mTitleText.setText("未清洗任务详情");
        setMsg();
    }

    /**
     * 添加数据
     * <p>
     * 预约状态 1已预约（未清洗） 2已取消  3洗车工清洗已确认 4用户清洗确认 5已评价
     */
    private void setMsg() {
        Intent intent = getIntent();
        if (intent == null) {
            return;
        }
        String name = intent.getStringExtra("username");
        String phone = intent.getStringExtra("phone");
        String car_info_park = intent.getStringExtra("car_info_park");
        String car_info_plate = intent.getStringExtra("car_info_plate");
        String reserve_status = intent.getStringExtra("reserve_status");
        String package_name = intent.getStringExtra("package_name");

        mReserve_time = intent.getLongExtra("reserve_time", 0);
        String community_layer_info_id = intent.getStringExtra("community_layer_info_id");
        String order_tip = intent.getStringExtra("order_tip");
        mStaffId = SharePreferenceUtils.getStaffId(context, AppConstant.USER_SP_NAME);
        mReserve_info_id = intent.getStringExtra("reserve_info_id");
        mOrder_id = intent.getIntExtra("order_id",0);
        mUserName.setText(name + " " + phone);
        mCarNumber.setText(car_info_plate);
        mStopSite.setText("负" + community_layer_info_id + "楼" + car_info_park);
        mUserRemark.setText(order_tip);
        mOrderTime.setText(AppUtils.formatDate(mReserve_time * 1000));
        mProductType.setText(package_name);
    }

    @Override
    protected void setListener() {

    }

    @Override
    protected int getLayoutID() {
        return R.layout.activity_not_accomplish_detail;
    }


    @OnClick({R.id.title_back, R.id.clear_forward1,
            R.id.clear_forward2, R.id.clear_back1,
            R.id.clear_back2, R.id.delay_oneday,
            R.id.sure_clear, R.id.delete_forward1,
            R.id.delete_forward2,R.id.delete_back1,
            R.id.delete_back2})
    public void onClick(View view) {
        final Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        switch (view.getId()) {
            case R.id.title_back:
                finish();
                break;
            case R.id.clear_forward1:
                startActivityForResult(intent, REQUEST_CODE_CAMERA1);
                break;
            case R.id.clear_forward2:
                startActivityForResult(intent, REQUEST_CODE_CAMERA2);
                break;
            case R.id.clear_back1:
                startActivityForResult(intent, REQUEST_CODE_CAMERA3);
                break;
            case R.id.clear_back2:
                startActivityForResult(intent, REQUEST_CODE_CAMERA4);
                break;
            case R.id.delay_oneday: //延迟一天
                AlertDialog.Builder delayBuilder = new AlertDialog.Builder(context);
                View delayDialog = getLayoutInflater().inflate(R.layout.dialog_clear_delay, null);
                RadioGroup rg = (RadioGroup) delayDialog.findViewById(R.id.dialog_rg);

                final RadioButton dialogRb1 = (RadioButton) delayDialog.findViewById(R.id.dialog_rg1);
                final RadioButton dialogRb2 = (RadioButton) delayDialog.findViewById(R.id.dialog_rg2);
                final RadioButton dialogRb3 = (RadioButton) delayDialog.findViewById(R.id.dialog_rg3);
                TextView quit = (TextView) delayDialog.findViewById(R.id.quit);
                TextView sure = (TextView) delayDialog.findViewById(R.id.sure);

                //其他原因
                final EditText otherReason = (EditText) delayDialog.findViewById(R.id.other_reason);

                rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, int checkedId) {
                        int childCount = group.getChildCount();
                        for (int i = 0; i < childCount; i++) {
                            RadioButton radioButton= (RadioButton) group.getChildAt(i);
                            if (radioButton.isChecked()){
                                mDeyReason = radioButton.getText().toString();
                                otherReason.setText("");
                            }
                        }
                    }
                });
                otherReason.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        String otherReasonMsg = otherReason.getText().toString();
                        if (!TextUtils.isEmpty(otherReasonMsg)){
                            dialogRb1.setChecked(false);
                            dialogRb2.setChecked(false);
                            dialogRb3.setChecked(false);
                            mDeyReason = otherReasonMsg;
                        }
                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });


                delayBuilder.setView(delayDialog);
                mAlertDialog1 = delayBuilder.create();
                mAlertDialog1.show();
                quit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mAlertDialog1.dismiss();
                    }
                });

                sure.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        delayOnDayRequest(mReserve_info_id,( mReserve_time+ 24 * 60 * 60),mDeyReason);
                    }
                });

                break;
            case R.id.sure_clear://确认清洗
                //判断是否有网络
                boolean connected = JudgeNetWork.isConnected(context);

                if (connected == true){ //有网
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    final View dialogView = getLayoutInflater().inflate(R.layout.dialog_clear_finish, null);
                    TextView quit2 = (TextView) dialogView.findViewById(R.id.quit);
                    TextView sure2 = (TextView) dialogView.findViewById(R.id.sure);

                    builder.setView(dialogView);
                    mAlertDialog = builder.create();
                    mAlertDialog.show();
                    quit2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mAlertDialog.dismiss();
                        }
                    });

                    sure2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String imgBeforeId = "";
                            String imgAfterId = "";
                            //洗车前照片ids
                            if (!TextUtils.isEmpty(imgBefore1Id)) {
                                imgBeforeId = imgBeforeId + imgBefore1Id;
                            }else {
                                if (!TextUtils.isEmpty(imgBefore2Id)) {
                                    imgBeforeId = imgBefore2Id;
                                }
                            }
                            if (!TextUtils.isEmpty(imgBefore2Id)) {
                                imgBeforeId = imgBeforeId + "," + imgBefore2Id;
                            }
                            //洗车后照片ids
                            if (!TextUtils.isEmpty(imgAfter1Id)) {
                                imgAfterId = imgAfterId + imgAfter1Id;
                            }else {
                                if (!TextUtils.isEmpty(imgAfter2Id)) {
                                    imgAfterId = imgAfter2Id;
                                }
                            }
                            if (!TextUtils.isEmpty(imgAfter2Id)) {
                                imgAfterId = imgAfterId + "," + imgAfter2Id;
                            }
                            String staffRemark = mStaffRemark.getText().toString();
                            if (TextUtils.isEmpty(staffRemark)) {
                                staffRemark = "";
                            }
                            //添加清洗详情信息网络请求

                            addClearDetailInfo(mReserve_info_id, imgBeforeId, imgAfterId, staffRemark, mStaffId,3);
                        }
                    });
                }else {//无网络
                    AlertDialog.Builder noeNetDialog = new AlertDialog.Builder(context);
                    View cacheView = getLayoutInflater().inflate(R.layout.dialog_cache, null);
                    TextView quit2 = (TextView) cacheView.findViewById(R.id.quit);
                    TextView sure2 = (TextView) cacheView.findViewById(R.id.sure);
                    noeNetDialog.setView(cacheView);
                    final AlertDialog alertDialog = noeNetDialog.create();
                    alertDialog.show();
                    quit2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                        }
                    });
                    sure2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (mDbManager == null) {
                                mDbManager = DBManager.getDBManager(context);
                            }
                            final ContentValues values = new ContentValues();
                            values.put("order_id",mOrder_id);
                            values.put("resever_info_id",mReserve_info_id);
                            values.put("before_wash_car1", dirName + "/"+ mFileBeforeName1);
                            values.put("before_wash_car2", dirName + "/" + mFileBeforeName2);
                            values.put("after_wash_car1", dirName + "/" + mFileAfterName1);
                            values.put("after_wash_car2", dirName + "/"+ mFileAfterName2);
                            //Log.i("TGA", dirName + "/"+ mFileBeforeName1);
                            values.put("clear_tip",mStaffRemark.getText().toString());
                            values.put("clear_status",3); //清洗状态 3表示已清洗
                            values.put("is_upload",0);  //是否上传 0 表示未上传，1表示已上传
                            values.put("staff_id", mStaffId);
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    Message msg = new Message();
                                    int update = mDbManager.update(TABLE_NAME, values, "resever_info_id = ?", new String[]{mReserve_info_id});

                                    if (update == 0){
                                        long insert = mDbManager.insert(TABLE_NAME, "0", values);
                                        if (insert >0){
                                            msg.what = 1;
                                            mHandler.sendMessage(msg);
                                        }else {
                                            msg.what = 2;
                                            mHandler.sendMessage(msg);
                                        }
                                    }else {
                                        msg.what = 3;
                                        mHandler.sendMessage(msg);
                                    }
                                }
                            }).start();
                            alertDialog.dismiss();
                            setResult(RESULT_OK,null);
                            finish();
                        }
                    });
                }

                break;
            case R.id.delete_forward1: //删除洗车前第一张图片
                mClearForward1.setImageResource(R.mipmap.add_image);
                deleteImageRequest(AppConstant.DELETE_BEFORE_IMG, 1, imgBefore1Id, null, imgBefore1Path);
                mDeletaForward1.setVisibility(View.GONE);
                break;
            case R.id.delete_forward2:
                mClearForward2.setImageResource(R.mipmap.add_image);
                deleteImageRequest(AppConstant.DELETE_BEFORE_IMG, 1, imgBefore2Id, null, imgBefore2Path);
                mDeletaForward2.setVisibility(View.GONE);
                break;
            case R.id.delete_back1:
                mClearBack1.setImageResource(R.mipmap.add_image);
                deleteImageRequest(AppConstant.DELETE_AFTER_IMG, 2, null, imgAfter1Id, imgAfter1Path);
                mDeletaAfter1.setVisibility(View.GONE);
                break;
            case R.id.delete_back2:
                mClearBack2.setImageResource(R.mipmap.add_image);
                deleteImageRequest(AppConstant.DELETE_AFTER_IMG, 2, null, imgAfter2Id, imgAfter2Path);
                mDeleteAfter2.setVisibility(View.GONE);
                break;

        }
    }

    //延迟一天网络请求
    private void delayOnDayRequest(String reserve_info_id,long new_reserve_time,String delay_reason) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("reserve_info_id",reserve_info_id);
        params.put("new_reserve_time",new_reserve_time);
        params.put("delay_reason",delay_reason);
        NetWorkUtils.requestPHP(context, params, AppConstant.DELAY_ONE_DAY, new NetWorkUtils.NetWorkUtilsCallbackPHP() {
            @Override
            public void onError(int id) {
                NetWorkUtils.cacheMiss(context,id);
            }

            @Override
            public void onWarn(String msg) {
                AppUtils.setToastMsg(context,msg);
            }

            @Override
            public void onResponse(JSONObject t) {
                AppUtils.setToastMsg(context, t.optString("msg"));
                mAlertDialog1.dismiss();
            }
        });
    }


    //添加清洗详情信息网络请求
    private void addClearDetailInfo(String reserve_info_id,String clear_before_img_ids,
                                    String clear_after_img_ids,String clear_remarks,
                                    String staff_id,int reserve_status) {
       // System.out.println("======>clear_before_img_ids = " + clear_before_img_ids + " ,clear_after_img_ids = " + clear_after_img_ids);
        HashMap<String, Object> params = new HashMap<>();
        params.put("reserve_info_id",reserve_info_id);
        if (!TextUtils.isEmpty(clear_before_img_ids)){
            params.put("clear_before_img_ids",clear_before_img_ids);
        }

        if (!TextUtils.isEmpty(clear_after_img_ids)){
            params.put("clear_after_img_ids",clear_after_img_ids);
        }
        params.put("clear_remarks",clear_remarks);
        params.put("staff_id",staff_id);
        params.put("reserve_status",reserve_status);

        NetWorkUtils.requestPHP(context, params, AppConstant.ADD_CLEAR_DETAIL_INFO, new NetWorkUtils.NetWorkUtilsCallbackPHP() {
            @Override
            public void onError(int id) {
                NetWorkUtils.cacheMiss(context,id);
            }

            @Override
            public void onWarn(String msg) {
                AppUtils.setToastMsg(context,msg);
            }

            @Override
            public void onResponse(JSONObject t) {
                AppUtils.setToastMsg(context,t.optString("msg"));
                mAlertDialog.dismiss();
                setResult(RESULT_OK, null);
                finish();
            }
        });
    }


    //删除图片网络请求
    private void deleteImageRequest(String url, int type, String clear_before_img_id, String clear_after_img_id, String path) {
        HashMap<String, Object> params = new HashMap<>();
        if (type == 1) {
            params.put("clear_before_img_id", clear_before_img_id);
        } else {
            params.put("clear_after_img_id", clear_after_img_id);
        }
        params.put("path", path);
        NetWorkUtils.requestPHP(context, params, url, new NetWorkUtils.NetWorkUtilsCallbackPHP() {
            @Override
            public void onError(int id) {
                NetWorkUtils.cacheMiss(context, id);
            }

            @Override
            public void onWarn(String msg) {
                AppUtils.setToastMsg(context, msg);
            }

            @Override
            public void onResponse(JSONObject t) {
                String msg = t.optString("msg");
                AppUtils.setToastMsg(context, msg);
            }
        });
    }

    //添加图片网络请求
    private void imgRequest(String url, String imgFileName, final int number,int type) {
        HashMap<String, Object> params = new HashMap<>();
        File file = new File(imgFileName);
        FileInputStream inputFile = null;
        try {
            inputFile = new FileInputStream(file);
            byte[] buffer = new byte[(int) file.length()];
            inputFile.read(buffer);
            String s = Base64.encodeToString(buffer, Base64.DEFAULT);
            //System.out.println("=====>" + s);
            if (type == 1){
                params.put("clear_before_img", s);
            }else {
                params.put("clear_after_img", s);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (inputFile != null) {
                try {
                    inputFile.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        NetWorkUtils.requestPHP(context, params, url, new NetWorkUtils.NetWorkUtilsCallbackPHP() {
            @Override
            public void onError(int id) {
                NetWorkUtils.cacheMiss(context, id);
            }

            @Override
            public void onWarn(String msg) {
                //AppUtils.setToastMsg(context, msg);
            }

            @Override
            public void onResponse(JSONObject t) {
                JSONObject jsonObject = t.optJSONObject("result");
                if (jsonObject == null) {
                    AppUtils.setToastMsg(context, "没有数据");
                    return;
                }
                ImageBean bean = JSONUtils.getBean(jsonObject, ImageBean.class);
                switch (number) {
                    case 1:
                        imgBefore1Path = bean.getPath();
                        imgBefore1Id = bean.getId();
                        //System.out.println("========>imgBefore1Id = "+ imgBefore1Id);
                        break;
                    case 2:
                        imgBefore2Path = bean.getPath();
                        imgBefore2Id = bean.getId();
                        //System.out.println("========>imgBefore2Id = "+ imgBefore2Id);
                        break;
                    case 3:
                        imgAfter1Path = bean.getPath();
                        imgAfter1Id = bean.getId();
                       // System.out.println("========>imgAfter1Id = "+ imgAfter1Id);
                        break;
                    case 4:
                        imgAfter2Path = bean.getPath();
                        imgAfter2Id = bean.getId();
                        //System.out.println("========>imgAfter2Id = "+ imgAfter2Id);
                        break;
                }
                AppUtils.setToastMsg(context, "图片上传成功");
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //洗车前第2张图
        if (requestCode == REQUEST_CODE_CAMERA1 && resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            // 获取相机返回的数据，并转换为Bitmap图片格式 ，这是缩略图
            Bitmap bitmap = (Bitmap) bundle.get("data");
            mClearForward1.setImageDrawable(new BitmapDrawable(bitmap));
            mFileBeforeName1 = mReserve_info_id + "before1";
            BitmapFactoryUtils.saveImage(context, bitmap, AppConstant.STAFF_FILENAME,mFileBeforeName1);
                /*dirName + "/"+ mFileBeforeName1*/
            imgRequest(AppConstant.URL_CLEAR_BEFORE_IMG, dirName + File.separator + mFileBeforeName1, 1,1);

            mDeletaForward1.setVisibility(View.VISIBLE);
        }
        //洗车前第2张图
        if (requestCode == REQUEST_CODE_CAMERA2 && resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            // 获取相机返回的数据，并转换为Bitmap图片格式 ，这是缩略图
            Bitmap bitmap = (Bitmap) bundle.get("data");
            mClearForward2.setImageDrawable(new BitmapDrawable(bitmap));
            mFileBeforeName2 = mReserve_info_id + "before2";
            BitmapFactoryUtils.saveImage(context, bitmap, AppConstant.STAFF_FILENAME, mFileBeforeName2);
            imgRequest(AppConstant.URL_CLEAR_BEFORE_IMG, dirName + File.separator + mFileBeforeName2, 2,1);
            mDeletaForward2.setVisibility(View.VISIBLE);
        }

        //洗车后第1张图片
        if (requestCode == REQUEST_CODE_CAMERA3 && resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            // 获取相机返回的数据，并转换为Bitmap图片格式 ，这是缩略图
            Bitmap bitmap = (Bitmap) bundle.get("data");
            mClearBack1.setImageDrawable(new BitmapDrawable(bitmap));
            mFileAfterName1 = mReserve_info_id + "after1";
            BitmapFactoryUtils.saveImage(context, bitmap, AppConstant.STAFF_FILENAME, mFileAfterName1);
            imgRequest(AppConstant.URL_CLEAR_AFTER_IMG, dirName + File.separator + mFileAfterName1, 3,2);
            mDeletaAfter1.setVisibility(View.VISIBLE);
        }
        //洗车后第2张图片
        if (requestCode == REQUEST_CODE_CAMERA4 && resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            // 获取相机返回的数据，并转换为Bitmap图片格式 ，这是缩略图
            Bitmap bitmap = (Bitmap) bundle.get("data");
            mClearBack2.setImageDrawable(new BitmapDrawable(bitmap));
            mFileAfterName2 = mReserve_info_id + "after2";
            BitmapFactoryUtils.saveImage(context, bitmap, AppConstant.STAFF_FILENAME, mFileAfterName2);
            imgRequest(AppConstant.URL_CLEAR_AFTER_IMG, dirName + File.separator + mFileAfterName2, 4,2);
            mDeleteAfter2.setVisibility(View.VISIBLE);
        }
    }

}
