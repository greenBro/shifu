package yuangong.id.bean;

/**
 * Created by 杨操 on 2016/10/12.
 * 描述：
 */
public class AddressBean {

    /**
     * community_info_id : 1
     * community_info_name : 绿地世纪城
     * community_info_province : 四川
     * community_info_city : 成都
     * community_info_conty : 武侯区
     */

    private String community_info_id;
    private String community_info_name;
    private String community_info_province;
    private String community_info_city;
    private String community_info_conty;

    public String getCommunity_info_id() {
        return community_info_id;
    }

    public void setCommunity_info_id(String community_info_id) {
        this.community_info_id = community_info_id;
    }

    public String getCommunity_info_name() {
        return community_info_name;
    }

    public void setCommunity_info_name(String community_info_name) {
        this.community_info_name = community_info_name;
    }

    public String getCommunity_info_province() {
        return community_info_province;
    }

    public void setCommunity_info_province(String community_info_province) {
        this.community_info_province = community_info_province;
    }

    public String getCommunity_info_city() {
        return community_info_city;
    }

    public void setCommunity_info_city(String community_info_city) {
        this.community_info_city = community_info_city;
    }

    public String getCommunity_info_conty() {
        return community_info_conty;
    }

    public void setCommunity_info_conty(String community_info_conty) {
        this.community_info_conty = community_info_conty;
    }
}
