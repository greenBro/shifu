package yuangong.id.bean;

import java.util.List;

/**
 * Created by Mathy on 2016/9/20 0020.
 * 描述：
 */
public class OnLineOrderBean {

    /**
     * order_id : 122
     * order_use_info_id : 114
     * order_presention_id : 0
     * user_id : 12
     * package_id : 4
     * server_address_id : 2
     * order_count_ids : 221
     * number : 2016101356525010
     * order_number : 2016101356525010
     * order_package_num : 1
     * start_time : 0
     * end_time : 0
     * order_paytime : 1476412656
     * original_money : 1.00
     * true_money : 1.00
     * order_status : 2
     * order_renew_present_status : 1
     * order_payment_way : 1
     * order_tip : 12
     * created_time : 1476324776
     * user_info : {"id":"12","server_address_ids":"1","user_coupon_ids":"1","nikename":"1","birthday":"1","truename":"1","status":"1","mobile":"1","email":"1","tel":"1","salt":"1","password":"1","photo":"1","create_time":"1","com_id":null,"inviter_id":null,"last_login_time":null}
     * package_info : {"package_id":"4","car_type_id":"1","community_info_id":"1","package_count_ids":"5","package_image_ids":"4","package_name":"测试套餐图片(勿用)","package_discribe":"1","package_price":"1","package_paynum":"39","package_month":"2","start_time":"0","end_time":"1601481600","created_time":"1476169653","package_type":"1","package_status":"1","package_count":[{"package_count_id":"5","package_count_type_id":"1","package_count_num":"2","created_time":"1476169653","package_count_type":[{"package_count_type_id":"1","package_count_type":"内饰清洗","created_time":"0"}]}],"package_image":[{"package_image_id":"4","package_imagepath":"./Public/Uploads/Package/1476169653620.jpeg","created_time":"1476169653"}]}
     * server_address_info : {"server_address_id":"2","user_id":"12","community_info_id":"3","community_layer_info_id":"1","name":"你在","mobile":"18756491853","car_info_id":"1","server_address_status":"0","status":"2","created_time":"0","car_info":{"car_info_id":"1","car_brand_model_id":"0","car_info_plate":"川B46981","car_type_id":"1","car_info_park":"。。。。。","created_time":"1476088400","car_type":{"car_type_id":"1","car_type":"精致轿车","created_time":"2147483647"}},"community_info":{"community_info_id":"3","staff_ids":"1","community_layer_info_ids":"1,2,3","community_info_name":"莲花逸都","community_info_province":"四川省","community_info_city":"成都市","community_info_conty":"武侯区","created_time":"1476087822","community_layer_info":[{"community_layer_info_id":"1","layer_name":"负一层"},{"community_layer_info_id":"2","layer_name":"负二层"},{"community_layer_info_id":"3","layer_name":"负三层"}]}}
     */

    private String order_id;
    private String order_use_info_id;
    private String order_presention_id;
    private String user_id;
    private String package_id;
    private String server_address_id;
    private String order_count_ids;
    private String number;
    private String order_number;
    private String order_package_num;
    private String start_time;
    private String end_time;
    private long order_paytime;
    private String original_money;
    private String true_money;
    private String order_status;
    private String order_renew_present_status;
    private String order_payment_way;
    private String order_tip;
    private String created_time;
    /**
     * id : 12
     * server_address_ids : 1
     * user_coupon_ids : 1
     * nikename : 1
     * birthday : 1
     * truename : 1
     * status : 1
     * mobile : 1
     * email : 1
     * tel : 1
     * salt : 1
     * password : 1
     * photo : 1
     * create_time : 1
     * com_id : null
     * inviter_id : null
     * last_login_time : null
     */

    private UserInfoBean user_info;
    /**
     * package_id : 4
     * car_type_id : 1
     * community_info_id : 1
     * package_count_ids : 5
     * package_image_ids : 4
     * package_name : 测试套餐图片(勿用)
     * package_discribe : 1
     * package_price : 1
     * package_paynum : 39
     * package_month : 2
     * start_time : 0
     * end_time : 1601481600
     * created_time : 1476169653
     * package_type : 1
     * package_status : 1
     * package_count : [{"package_count_id":"5","package_count_type_id":"1","package_count_num":"2","created_time":"1476169653","package_count_type":[{"package_count_type_id":"1","package_count_type":"内饰清洗","created_time":"0"}]}]
     * package_image : [{"package_image_id":"4","package_imagepath":"./Public/Uploads/Package/1476169653620.jpeg","created_time":"1476169653"}]
     */

    private PackageInfoBean package_info;
    /**
     * server_address_id : 2
     * user_id : 12
     * community_info_id : 3
     * community_layer_info_id : 1
     * name : 你在
     * mobile : 18756491853
     * car_info_id : 1
     * server_address_status : 0
     * status : 2
     * created_time : 0
     * car_info : {"car_info_id":"1","car_brand_model_id":"0","car_info_plate":"川B46981","car_type_id":"1","car_info_park":"。。。。。","created_time":"1476088400","car_type":{"car_type_id":"1","car_type":"精致轿车","created_time":"2147483647"}}
     * community_info : {"community_info_id":"3","staff_ids":"1","community_layer_info_ids":"1,2,3","community_info_name":"莲花逸都","community_info_province":"四川省","community_info_city":"成都市","community_info_conty":"武侯区","created_time":"1476087822","community_layer_info":[{"community_layer_info_id":"1","layer_name":"负一层"},{"community_layer_info_id":"2","layer_name":"负二层"},{"community_layer_info_id":"3","layer_name":"负三层"}]}
     */

    private ServerAddressInfoBean server_address_info;

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getOrder_use_info_id() {
        return order_use_info_id;
    }

    public void setOrder_use_info_id(String order_use_info_id) {
        this.order_use_info_id = order_use_info_id;
    }

    public String getOrder_presention_id() {
        return order_presention_id;
    }

    public void setOrder_presention_id(String order_presention_id) {
        this.order_presention_id = order_presention_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getPackage_id() {
        return package_id;
    }

    public void setPackage_id(String package_id) {
        this.package_id = package_id;
    }

    public String getServer_address_id() {
        return server_address_id;
    }

    public void setServer_address_id(String server_address_id) {
        this.server_address_id = server_address_id;
    }

    public String getOrder_count_ids() {
        return order_count_ids;
    }

    public void setOrder_count_ids(String order_count_ids) {
        this.order_count_ids = order_count_ids;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getOrder_number() {
        return order_number;
    }

    public void setOrder_number(String order_number) {
        this.order_number = order_number;
    }

    public String getOrder_package_num() {
        return order_package_num;
    }

    public void setOrder_package_num(String order_package_num) {
        this.order_package_num = order_package_num;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public long getOrder_paytime() {
        return order_paytime * 1000;
    }

    public void setOrder_paytime(long order_paytime) {
        this.order_paytime = order_paytime;
    }

    public String getOriginal_money() {
        return original_money;
    }

    public void setOriginal_money(String original_money) {
        this.original_money = original_money;
    }

    public String getTrue_money() {
        return true_money;
    }

    public void setTrue_money(String true_money) {
        this.true_money = true_money;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public String getOrder_renew_present_status() {
        return order_renew_present_status;
    }

    public void setOrder_renew_present_status(String order_renew_present_status) {
        this.order_renew_present_status = order_renew_present_status;
    }

    public String getOrder_payment_way() {
        return order_payment_way;
    }

    public void setOrder_payment_way(String order_payment_way) {
        this.order_payment_way = order_payment_way;
    }

    public String getOrder_tip() {
        return order_tip;
    }

    public void setOrder_tip(String order_tip) {
        this.order_tip = order_tip;
    }

    public String getCreated_time() {
        return created_time;
    }

    public void setCreated_time(String created_time) {
        this.created_time = created_time;
    }

    public UserInfoBean getUser_info() {
        return user_info;
    }

    public void setUser_info(UserInfoBean user_info) {
        this.user_info = user_info;
    }

    public PackageInfoBean getPackage_info() {
        return package_info;
    }

    public void setPackage_info(PackageInfoBean package_info) {
        this.package_info = package_info;
    }

    public ServerAddressInfoBean getServer_address_info() {
        return server_address_info;
    }

    public void setServer_address_info(ServerAddressInfoBean server_address_info) {
        this.server_address_info = server_address_info;
    }

    public static class UserInfoBean {
        private String id;
        private String server_address_ids;
        private String user_coupon_ids;
        private String nikename;
        private String birthday;
        private String truename;
        private String status;
        private String mobile;
        private String email;
        private String tel;
        private String salt;
        private String password;
        private String photo;
        private String create_time;
        private String com_id;
        private String inviter_id;
        private String last_login_time;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getServer_address_ids() {
            return server_address_ids;
        }

        public void setServer_address_ids(String server_address_ids) {
            this.server_address_ids = server_address_ids;
        }

        public String getUser_coupon_ids() {
            return user_coupon_ids;
        }

        public void setUser_coupon_ids(String user_coupon_ids) {
            this.user_coupon_ids = user_coupon_ids;
        }

        public String getNikename() {
            return nikename;
        }

        public void setNikename(String nikename) {
            this.nikename = nikename;
        }

        public String getBirthday() {
            return birthday;
        }

        public void setBirthday(String birthday) {
            this.birthday = birthday;
        }

        public String getTruename() {
            return truename;
        }

        public void setTruename(String truename) {
            this.truename = truename;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getTel() {
            return tel;
        }

        public void setTel(String tel) {
            this.tel = tel;
        }

        public String getSalt() {
            return salt;
        }

        public void setSalt(String salt) {
            this.salt = salt;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getPhoto() {
            return photo;
        }

        public void setPhoto(String photo) {
            this.photo = photo;
        }

        public String getCreate_time() {
            return create_time;
        }

        public void setCreate_time(String create_time) {
            this.create_time = create_time;
        }

        public String getCom_id() {
            return com_id;
        }

        public void setCom_id(String com_id) {
            this.com_id = com_id;
        }

        public String getInviter_id() {
            return inviter_id;
        }

        public void setInviter_id(String inviter_id) {
            this.inviter_id = inviter_id;
        }

        public String getLast_login_time() {
            return last_login_time;
        }

        public void setLast_login_time(String last_login_time) {
            this.last_login_time = last_login_time;
        }
    }

    public static class PackageInfoBean {
        private String package_id;
        private String car_type_id;
        private String community_info_id;
        private String package_count_ids;
        private String package_image_ids;
        private String package_name;
        private String package_discribe;
        private String package_price;
        private String package_paynum;
        private String package_month;
        private String start_time;
        private String end_time;
        private String created_time;
        private String package_type;
        private String package_status;
        /**
         * package_count_id : 5
         * package_count_type_id : 1
         * package_count_num : 2
         * created_time : 1476169653
         * package_count_type : [{"package_count_type_id":"1","package_count_type":"内饰清洗","created_time":"0"}]
         */

        private List<PackageCountBean> package_count;
        /**
         * package_image_id : 4
         * package_imagepath : ./Public/Uploads/Package/1476169653620.jpeg
         * created_time : 1476169653
         */

        private List<PackageImageBean> package_image;

        public String getPackage_id() {
            return package_id;
        }

        public void setPackage_id(String package_id) {
            this.package_id = package_id;
        }

        public String getCar_type_id() {
            return car_type_id;
        }

        public void setCar_type_id(String car_type_id) {
            this.car_type_id = car_type_id;
        }

        public String getCommunity_info_id() {
            return community_info_id;
        }

        public void setCommunity_info_id(String community_info_id) {
            this.community_info_id = community_info_id;
        }

        public String getPackage_count_ids() {
            return package_count_ids;
        }

        public void setPackage_count_ids(String package_count_ids) {
            this.package_count_ids = package_count_ids;
        }

        public String getPackage_image_ids() {
            return package_image_ids;
        }

        public void setPackage_image_ids(String package_image_ids) {
            this.package_image_ids = package_image_ids;
        }

        public String getPackage_name() {
            return package_name;
        }

        public void setPackage_name(String package_name) {
            this.package_name = package_name;
        }

        public String getPackage_discribe() {
            return package_discribe;
        }

        public void setPackage_discribe(String package_discribe) {
            this.package_discribe = package_discribe;
        }

        public String getPackage_price() {
            return package_price;
        }

        public void setPackage_price(String package_price) {
            this.package_price = package_price;
        }

        public String getPackage_paynum() {
            return package_paynum;
        }

        public void setPackage_paynum(String package_paynum) {
            this.package_paynum = package_paynum;
        }

        public String getPackage_month() {
            return package_month;
        }

        public void setPackage_month(String package_month) {
            this.package_month = package_month;
        }

        public String getStart_time() {
            return start_time;
        }

        public void setStart_time(String start_time) {
            this.start_time = start_time;
        }

        public String getEnd_time() {
            return end_time;
        }

        public void setEnd_time(String end_time) {
            this.end_time = end_time;
        }

        public String getCreated_time() {
            return created_time;
        }

        public void setCreated_time(String created_time) {
            this.created_time = created_time;
        }

        public String getPackage_type() {
            return package_type;
        }

        public void setPackage_type(String package_type) {
            this.package_type = package_type;
        }

        public String getPackage_status() {
            return package_status;
        }

        public void setPackage_status(String package_status) {
            this.package_status = package_status;
        }

        public List<PackageCountBean> getPackage_count() {
            return package_count;
        }

        public void setPackage_count(List<PackageCountBean> package_count) {
            this.package_count = package_count;
        }

        public List<PackageImageBean> getPackage_image() {
            return package_image;
        }

        public void setPackage_image(List<PackageImageBean> package_image) {
            this.package_image = package_image;
        }

        public static class PackageCountBean {
            private String package_count_id;
            private String package_count_type_id;
            private String package_count_num;
            private String created_time;
            /**
             * package_count_type_id : 1
             * package_count_type : 内饰清洗
             * created_time : 0
             */

            private List<PackageCountTypeBean> package_count_type;

            public String getPackage_count_id() {
                return package_count_id;
            }

            public void setPackage_count_id(String package_count_id) {
                this.package_count_id = package_count_id;
            }

            public String getPackage_count_type_id() {
                return package_count_type_id;
            }

            public void setPackage_count_type_id(String package_count_type_id) {
                this.package_count_type_id = package_count_type_id;
            }

            public String getPackage_count_num() {
                return package_count_num;
            }

            public void setPackage_count_num(String package_count_num) {
                this.package_count_num = package_count_num;
            }

            public String getCreated_time() {
                return created_time;
            }

            public void setCreated_time(String created_time) {
                this.created_time = created_time;
            }

            public List<PackageCountTypeBean> getPackage_count_type() {
                return package_count_type;
            }

            public void setPackage_count_type(List<PackageCountTypeBean> package_count_type) {
                this.package_count_type = package_count_type;
            }

            public static class PackageCountTypeBean {
                private String package_count_type_id;
                private String package_count_type;
                private String created_time;

                public String getPackage_count_type_id() {
                    return package_count_type_id;
                }

                public void setPackage_count_type_id(String package_count_type_id) {
                    this.package_count_type_id = package_count_type_id;
                }

                public String getPackage_count_type() {
                    return package_count_type;
                }

                public void setPackage_count_type(String package_count_type) {
                    this.package_count_type = package_count_type;
                }

                public String getCreated_time() {
                    return created_time;
                }

                public void setCreated_time(String created_time) {
                    this.created_time = created_time;
                }
            }
        }

        public static class PackageImageBean {
            private String package_image_id;
            private String package_imagepath;
            private String created_time;

            public String getPackage_image_id() {
                return package_image_id;
            }

            public void setPackage_image_id(String package_image_id) {
                this.package_image_id = package_image_id;
            }

            public String getPackage_imagepath() {
                return package_imagepath;
            }

            public void setPackage_imagepath(String package_imagepath) {
                this.package_imagepath = package_imagepath;
            }

            public String getCreated_time() {
                return created_time;
            }

            public void setCreated_time(String created_time) {
                this.created_time = created_time;
            }
        }
    }

    public static class ServerAddressInfoBean {
        private String server_address_id;
        private String user_id;
        private String community_info_id;
        private String community_layer_info_id;
        private String name;
        private String mobile;
        private String car_info_id;
        private String server_address_status;
        private String status;
        private String created_time;
        /**
         * car_info_id : 1
         * car_brand_model_id : 0
         * car_info_plate : 川B46981
         * car_type_id : 1
         * car_info_park : 。。。。。
         * created_time : 1476088400
         * car_type : {"car_type_id":"1","car_type":"精致轿车","created_time":"2147483647"}
         */

        private CarInfoBean car_info;
        /**
         * community_info_id : 3
         * staff_ids : 1
         * community_layer_info_ids : 1,2,3
         * community_info_name : 莲花逸都
         * community_info_province : 四川省
         * community_info_city : 成都市
         * community_info_conty : 武侯区
         * created_time : 1476087822
         * community_layer_info : [{"community_layer_info_id":"1","layer_name":"负一层"},{"community_layer_info_id":"2","layer_name":"负二层"},{"community_layer_info_id":"3","layer_name":"负三层"}]
         */

        private CommunityInfoBean community_info;

        public String getServer_address_id() {
            return server_address_id;
        }

        public void setServer_address_id(String server_address_id) {
            this.server_address_id = server_address_id;
        }

        public String getUser_id() {
            return user_id;
        }

        public void setUser_id(String user_id) {
            this.user_id = user_id;
        }

        public String getCommunity_info_id() {
            return community_info_id;
        }

        public void setCommunity_info_id(String community_info_id) {
            this.community_info_id = community_info_id;
        }

        public String getCommunity_layer_info_id() {
            return community_layer_info_id;
        }

        public void setCommunity_layer_info_id(String community_layer_info_id) {
            this.community_layer_info_id = community_layer_info_id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getCar_info_id() {
            return car_info_id;
        }

        public void setCar_info_id(String car_info_id) {
            this.car_info_id = car_info_id;
        }

        public String getServer_address_status() {
            return server_address_status;
        }

        public void setServer_address_status(String server_address_status) {
            this.server_address_status = server_address_status;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getCreated_time() {
            return created_time;
        }

        public void setCreated_time(String created_time) {
            this.created_time = created_time;
        }

        public CarInfoBean getCar_info() {
            return car_info;
        }

        public void setCar_info(CarInfoBean car_info) {
            this.car_info = car_info;
        }

        public CommunityInfoBean getCommunity_info() {
            return community_info;
        }

        public void setCommunity_info(CommunityInfoBean community_info) {
            this.community_info = community_info;
        }

        public static class CarInfoBean {
            private String car_info_id;
            private String car_brand_model_id;
            private String car_info_plate;
            private String car_type_id;
            private String car_info_park;
            private String created_time;
            /**
             * car_type_id : 1
             * car_type : 精致轿车
             * created_time : 2147483647
             */

            private CarTypeBean car_type;

            public String getCar_info_id() {
                return car_info_id;
            }

            public void setCar_info_id(String car_info_id) {
                this.car_info_id = car_info_id;
            }

            public String getCar_brand_model_id() {
                return car_brand_model_id;
            }

            public void setCar_brand_model_id(String car_brand_model_id) {
                this.car_brand_model_id = car_brand_model_id;
            }

            public String getCar_info_plate() {
                return car_info_plate;
            }

            public void setCar_info_plate(String car_info_plate) {
                this.car_info_plate = car_info_plate;
            }

            public String getCar_type_id() {
                return car_type_id;
            }

            public void setCar_type_id(String car_type_id) {
                this.car_type_id = car_type_id;
            }

            public String getCar_info_park() {
                return car_info_park;
            }

            public void setCar_info_park(String car_info_park) {
                this.car_info_park = car_info_park;
            }

            public String getCreated_time() {
                return created_time;
            }

            public void setCreated_time(String created_time) {
                this.created_time = created_time;
            }

            public CarTypeBean getCar_type() {
                return car_type;
            }

            public void setCar_type(CarTypeBean car_type) {
                this.car_type = car_type;
            }

            public static class CarTypeBean {
                private String car_type_id;
                private String car_type;
                private String created_time;

                public String getCar_type_id() {
                    return car_type_id;
                }

                public void setCar_type_id(String car_type_id) {
                    this.car_type_id = car_type_id;
                }

                public String getCar_type() {
                    return car_type;
                }

                public void setCar_type(String car_type) {
                    this.car_type = car_type;
                }

                public String getCreated_time() {
                    return created_time;
                }

                public void setCreated_time(String created_time) {
                    this.created_time = created_time;
                }
            }
        }

        public static class CommunityInfoBean {
            private String community_info_id;
            private String staff_ids;
            private String community_layer_info_ids;
            private String community_info_name;
            private String community_info_province;
            private String community_info_city;
            private String community_info_conty;
            private String created_time;
            /**
             * community_layer_info_id : 1
             * layer_name : 负一层
             */

            private List<CommunityLayerInfoBean> community_layer_info;

            public String getCommunity_info_id() {
                return community_info_id;
            }

            public void setCommunity_info_id(String community_info_id) {
                this.community_info_id = community_info_id;
            }

            public String getStaff_ids() {
                return staff_ids;
            }

            public void setStaff_ids(String staff_ids) {
                this.staff_ids = staff_ids;
            }

            public String getCommunity_layer_info_ids() {
                return community_layer_info_ids;
            }

            public void setCommunity_layer_info_ids(String community_layer_info_ids) {
                this.community_layer_info_ids = community_layer_info_ids;
            }

            public String getCommunity_info_name() {
                return community_info_name;
            }

            public void setCommunity_info_name(String community_info_name) {
                this.community_info_name = community_info_name;
            }

            public String getCommunity_info_province() {
                return community_info_province;
            }

            public void setCommunity_info_province(String community_info_province) {
                this.community_info_province = community_info_province;
            }

            public String getCommunity_info_city() {
                return community_info_city;
            }

            public void setCommunity_info_city(String community_info_city) {
                this.community_info_city = community_info_city;
            }

            public String getCommunity_info_conty() {
                return community_info_conty;
            }

            public void setCommunity_info_conty(String community_info_conty) {
                this.community_info_conty = community_info_conty;
            }

            public String getCreated_time() {
                return created_time;
            }

            public void setCreated_time(String created_time) {
                this.created_time = created_time;
            }

            public List<CommunityLayerInfoBean> getCommunity_layer_info() {
                return community_layer_info;
            }

            public void setCommunity_layer_info(List<CommunityLayerInfoBean> community_layer_info) {
                this.community_layer_info = community_layer_info;
            }

            public static class CommunityLayerInfoBean {
                private String community_layer_info_id;
                private String layer_name;

                public String getCommunity_layer_info_id() {
                    return community_layer_info_id;
                }

                public void setCommunity_layer_info_id(String community_layer_info_id) {
                    this.community_layer_info_id = community_layer_info_id;
                }

                public String getLayer_name() {
                    return layer_name;
                }

                public void setLayer_name(String layer_name) {
                    this.layer_name = layer_name;
                }
            }
        }
    }
}
