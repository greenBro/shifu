package yuangong.id.bean;

/**
 * Created by Mathy on 2016/9/27 0027.
 * 描述：
 */
public class CarTypeBean {



    private String car_type_id;
    private String car_type;
    private String created_time;

    public String getCar_type_id() {
        return car_type_id;
    }

    public void setCar_type_id(String car_type_id) {
        this.car_type_id = car_type_id;
    }

    public String getCar_type() {
        return car_type;
    }

    public void setCar_type(String car_type) {
        this.car_type = car_type;
    }

    public String getCreated_time() {
        return created_time;
    }

    public void setCreated_time(String created_time) {
        this.created_time = created_time;
    }
}
