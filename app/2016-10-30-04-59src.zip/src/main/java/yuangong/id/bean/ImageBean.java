package yuangong.id.bean;

/**
 * Created by Mathy on 2016/10/11 0011.
 * 描述：
 */
public class ImageBean {

    /**
     * id : 11
     * path : ./Public/Clear_Before_img/3ecdd603460f275fba4a420f62c5d1fe.png
     */

    private String id;
    private String path;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPath() {
            return "http://101.204.246.93/water"+path.substring(1,path.length());
        //return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
